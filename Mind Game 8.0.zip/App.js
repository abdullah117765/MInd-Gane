import React from "react";

//screens
import RootStack from "./Navigators/RootStack.js";

export default function App() {
  return <RootStack />;
}
